//
//  LiveOpsCore.h
//  LiveOps
//
//  Created by 강기태 on 2014. 7. 11..
//  Copyright (c) 2014년 IGAWorks. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface LiveOpsCore : NSObject

//+ (void)initLiveOps;
+ (void)initLiveOpsWithAppKey:(NSString*)appKey;

@end