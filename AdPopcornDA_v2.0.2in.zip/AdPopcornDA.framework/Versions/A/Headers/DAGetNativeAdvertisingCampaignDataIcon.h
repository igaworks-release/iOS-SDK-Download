//
//  DAGetNativeAdvertisingCampaignDataIcon.h
//  IgaworksAd
//
//  Created by wonje,song on 2014. 7. 11..
//  Copyright (c) 2014년 wonje,song. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DAGetNativeAdvertisingCampaignDataIcon : NSObject

@property (nonatomic, copy) NSString *url;
@property (nonatomic, unsafe_unretained) float width;
@property (nonatomic, unsafe_unretained) float height;


@end
